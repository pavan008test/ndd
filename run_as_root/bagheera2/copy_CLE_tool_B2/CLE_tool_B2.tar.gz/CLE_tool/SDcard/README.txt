Installation and usage guide for CLE on RDK
======================================================================

1. Copy files to target android device
	Copy the content of the package "cle.tar.gz" to target Android
	directory with execute permissions (denote as CLE_DIR,
	for example CLE_DIR=/data/local/tmp).

2. Run CLE
	$ ${CLE_DIR}/cle

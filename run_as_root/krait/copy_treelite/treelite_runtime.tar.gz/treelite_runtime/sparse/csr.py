import numpy as np

class csr_matrix:
    """
    Compressed Sparse Row matrix
    """
    def __init__(self, data, shape=None):
        if isinstance(data, np.ndarray):
            self.data = data
            self.indices = np.zeros_like(data)
            self.indptr = np.zeros((shape[0] + 1,), dtype=int)
        else:
            self.data, self.indices, self.indptr = data
        if shape is None:
            self.shape = (np.max(self.indices) + 1, self.indptr.shape[0] - 1)
        else:
            self.shape = shape

    def __getitem__(self, key):
        if isinstance(key, tuple):
            row, col = key
            if isinstance(row, int):
                return self.getrow(row)[0, col]
            elif isinstance(col, int):
                return self.getcol(col)[row, 0]
            else:
                return self._get_submatrix(row, col)
        else:
            return self.getrow(key)

    def __setitem__(self, key, value):
        if isinstance(key, tuple):
            row, col = key
            if isinstance(row, int):
                self.getrow(row)[0, col] = value
            elif isinstance(col, int):
                self.getcol(col)[row, 0] = value
            else:
                self._set_submatrix(row, col, value)
        else:
            self.getrow(key)[:] = value

    def __add__(self, other):
        if isinstance(other, csr_matrix):
            return self._add_csr(other)
        else:
            return self._add_dense(other)

    def __mul__(self, other):
        if isinstance(other, csr_matrix):
            return self._mul_csr(other)
        else:
            return self._mul_dense(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def transpose(self):
        data = self.data.copy()
        indices = self.indices.copy()
        indptr = np.zeros((self.shape[1] + 1,), dtype=int)
        np.cumsum(np.bincount(self.indices, minlength=self.shape[0]), out=indptr[1:])
        return csr_matrix((data, indices, indptr), shape=(self.shape[1], self.shape[0]))

    def getrow(self, i):
        row_start = self.indptr[i]
        row_end = self.indptr[i+1]
        row_data = self.data[row_start:row_end]
        row_indices = self.indices[row_start:row_end]
        row = np.zeros((1, self.shape[1]), dtype=self.data.dtype)
        row[0, row_indices] = row_data
        return row

    def getcol(self, j):
        col_indices = self.indices[self.indptr[j]:self.indptr[j+1]]
        col_data = self.data[self.indptr[j]:self.indptr[j+1]]
        col = np.zeros((self.shape[0], 1), dtype=self.data.dtype)
        col[col_indices, 0] = col_data
        return col

    def _get_submatrix(self, row_slice, col_slice):
        indptr = self.indptr
        indices = self.indices
        data = self.data
        row_start, row_stop, row_step = row_slice.indices(self.shape[0])
        col_start, col_stop, col_step = col_slice.indices(self.shape[1])
        row_indices = np.arange(row_start, row_stop, row_step)
        col_indices = np.arange(col_start, col_stop, col_step)
        row_indptr = np.zeros((len(row_indices) + 1,), dtype=int)
        row_nnz = 0
        for i, row in enumerate(row_indices):
            row_start = indptr[row]
            row_end = indptr[row + 1]
            row_nnz += len(np.where((col_indices >= row_start) & (col_indices < row_end))[0])
            row_indptr[i + 1] = row_nnz
        sub_data = np.zeros((row_nnz,), dtype=data.dtype)
        sub_indices = np.zeros((row_nnz,), dtype=indices.dtype)
        sub_indptr = np.zeros((len(col_indices) + 1,), dtype=int)
        sub_nnz = 0
        for i, col in enumerate(col_indices):
            col_start = indptr[col]
            col_end = indptr[col + 1]
            for j, row in enumerate(row_indices):
                row_start = indptr[row]
                row_end = indptr[row + 1]
                idx = np.where((indices >= col_start) & (indices < col_end) & (row_indices[j] == row))[0]
                if len(idx) > 0:
                    sub_data[sub_nnz] = data[idx[0]]
                    sub_indices[sub_nnz] = i
                    sub_nnz += 1
            sub_indptr[i + 1] = sub_nnz
        return csr_matrix((sub_data, sub_indices, sub_indptr), shape=(len(row_indices), len(col_indices)))

    def _set_submatrix(self, row_slice, col_slice, value):
        indptr = self.indptr
        indices = self.indices
        data = self.data
        row_start, row_stop, row_step = row_slice.indices(self.shape[0])
        col_start, col_stop, col_step = col_slice.indices(self.shape[1])
        row_indices = np.arange(row_start, row_stop, row_step)
        col_indices = np.arange(col_start, col_stop, col_step)
        row_indptr = np.zeros((len(row_indices) + 1,), dtype=int)
        row_nnz = 0
        for i, row in enumerate(row_indices):
            row_start = indptr[row]
            row_end = indptr[row + 1]
            row_nnz += len(np.where((col_indices >= row_start) & (col_indices < row_end))[0])
            row_indptr[i + 1] = row_nnz
        sub_data = np.zeros((row_nnz,), dtype=data.dtype)
        sub_indices = np.zeros((row_nnz,), dtype=indices.dtype)
        sub_indptr = np.zeros((len(col_indices) + 1,), dtype=int)
        sub_nnz = 0
        for i, col in enumerate(col_indices):
            col_start = indptr[col]
            col_end = indptr[col + 1]
            for j, row in enumerate(row_indices):
                row_start = indptr[row]
                row_end = indptr[row + 1]
                idx = np.where((indices >= col_start) & (indices < col_end) & (row_indices[j] == row))[0]
                if len(idx) > 0:
                    sub_data[sub_nnz] = data[idx[0]]
                    sub_indices[sub_nnz] = i
                    sub_nnz += 1
            sub_indptr[i + 1] = sub_nnz
        sub_matrix = csr_matrix((sub_data, sub_indices, sub_indptr), shape=(len(row_indices), len(col_indices)))
        if isinstance(value, csr_matrix):
            sub_matrix = sub_matrix._mul_csr(value)
        else:
            sub_matrix = sub_matrix._mul_dense(value)
        for i, row in enumerate(row_indices):
            row_start = row_indptr[i]
            row_end = row_indptr[i + 1]
            idx = np.where(sub_indices[row_start:row_end] >= 0)[0]
            data[row_start:row_start + len(idx)] = sub_matrix.data[row_start + idx]
            indices[row_start:row_start + len(idx)] = sub_indices[row_start + idx] + col_start
        for i, col in enumerate(col_indices):
            indptr[col + 1] += sub_indptr[i + 1] - sub_indptr[i]

    def _add_csr(self, other):
        if self.shape != other.shape:
            raise ValueError("matrix shapes not aligned")
        data = np.concatenate((self.data, other.data))
        indices = np.concatenate((self.indices, other.indices))
        indptr = self.indptr.copy()
        for i in range(1, len(other.indptr)):
            indptr[i] += other.indptr[i]
        return csr_matrix((data, indices, indptr), shape=self.shape)

    def _add_dense(self, other):
        if self.shape != other.shape:
            raise ValueError("matrix shapes not aligned")
        return self.toarray() + other

    def _mul_csr(self, other):
        if self.shape[1] != other.shape[0]:
            raise ValueError("matrix shapes not aligned")
        data = np.zeros((self.indptr[-1],), dtype=self.data.dtype)
        indices = np.zeros((self.indptr[-1],), dtype=self.indices.dtype)
        indptr = np.zeros((self.shape[0] + 1,), dtype=int)
        np.cumsum(np.bincount(self.indices, minlength=self.shape[1]), out=indptr[1:])
        other_indptr = other.indptr
        other_indices = other.indices
        other_data = other.data
        for i in range(self.shape[0]):
            row_start = indptr[i]
            row_end = indptr[i + 1]
            for j in range(other_indptr[i], other_indptr[i + 1]):
                col = other_indices[j]
                col_start = self.indptr[col]
                col_end = self.indptr[col + 1]
                idx = np.where((indices[col_start:col_end] == i))[0]
                if len(idx) > 0:
                    data[col_start + idx[0]] += data[row_start + idx[0]] * other_data[j]
                else:
                    indices[row_end] = i
                    data[row_end] = data[col_start] * other_data[j]
                    indptr[col + 1:] += 1
        return csr_matrix((data, indices, indptr), shape=(self.shape[0], other.shape[1]))

    def _mul_dense(self, other):
        if self.shape[1] != other.shape[0]:
            raise ValueError("matrix shapes not aligned")
        return self.toarray() @ other

    def toarray(self):
        dense_matrix = np.zeros(self.shape, dtype=self.data.dtype)
        for i in range(self.shape[0]):
            row_start = self.indptr[i]
            row_end = self.indptr[i + 1]
            row_indices = self.indices[row_start:row_end]
            row_data = self.data[row_start:row_end]
            dense_matrix[i, row_indices] = row_data
        return dense_matrix
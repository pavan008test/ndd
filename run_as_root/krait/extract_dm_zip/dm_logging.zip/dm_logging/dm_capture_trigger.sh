#!/bin/bash

if [[ ! -f /dev/shm/dmcapture_running ]]; then
        touch /dev/shm/dmcapture_running
        sleep 100
        cd /home/ubuntu/dm_logging
        a=0
        while [ $a -lt 144 ]
        do
            echo "loop: $a"
            echo "loop start"
            epoch_time=$(date +%s%3N)
            timeout -t 600 bash -c  "/home/ubuntu/dm_logging/dmcapture.sh -l -d /dev/ttyUSB0 -f v11026_Generic_GSM_WCDMA_LTE_IP.sqf -o /home/ubuntu/dm_logging/modem_swi.log"
            cp modem_swi.log /home/ubuntu/.nddevice/log/conn_mgr/modem_swi_${epoch_time}_loop${a}.log
            rm -f modem_swi.log
            a=$(( $a + 1 ))
            echo "loop end"
        done
        rm -f /dev/shm/dmcapture_running
        sudo rm -f /etc/systemd/system/dmcapture_trigger.service
        sudo reboot
else
            echo "dmcapture already running"
fi


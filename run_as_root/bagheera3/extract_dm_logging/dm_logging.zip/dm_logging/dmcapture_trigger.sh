#!/bin/bash
 
epoch_time=$(date +%s%3N)

if [[ ! -f /dev/shm/dmcapture_running ]]; then 
        touch /dev/shm/dmcapture_running
        sleep 100
        cd /home/ubuntu/dm_logging
        bash -c  "./dmcapture.sh -l -d /dev/ttyUSB0 -f v11026_Generic_GSM_WCDMA_LTE_IP.sqf -o /home/ubuntu/.nddevice/log/conn_mgr/modem_swi_${epoch_time}.log &"
        sleep 600
        rm -f /dev/shm/dmcapture_running
        sudo rm -f /etc/systemd/system/dmcapture_trigger.service
        sudo reboot
else 
            echo "dmcapture already running"
fi
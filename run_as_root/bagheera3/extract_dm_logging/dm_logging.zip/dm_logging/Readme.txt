// Create folder in device at /home/ubuntu by running following commands
cd
mkdir dm_logging

// Download the zip folder, copy to above folder in device and make sure md5sum matches
md5sum dm_logging.zip 
07e85a183e1d6ae569a621e87e5be5d7  dm_logging.zip

// Run following command. Log saves with name <log_file_name>. Please name log based on test case while running command
lte_gps_test 'AT+CFUN=0'
(for all rat log)
./dmcapture.sh -l -d /dev/ttyUSB0 -f v11026_Generic_GSM_WCDMA_LTE_IP.sqf -o <log_file_name> &
(for only nas rrc log)
./dmcapture.sh -l -d /dev/ttyUSB0 -f RC7611-NAS-RRC-QMI.sqf -o <log_file_name> &
lte_gps_test 'AT+CFUN=1'

// Once test case is done, stop logging by running following commands
pgrep -l "dmcapture.sh"
killall "dmcapture.sh"

// Send log file back to laptop by issuing following command
sz <log_file_name>

sudo ./dmcapture.sh -l -f filters/v11026_Generic_GSM_WCDMA_LTE_IP.sqf -d /dev/ttyUSB0 -o test_log_final.swi &

